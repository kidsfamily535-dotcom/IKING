// أربعة مفاهيم منفصلة — لا تدمجها أبداً
export type AgentState = 'IDLE' | 'ANALYSING' | 'ALL_CLEAR'
export type DataStatus = 'LIVE' | 'SIM' | 'ESTIMATED' | 'UNKNOWN' | 'CONFIRMED' | 'INFERRED'
export type EventPriority = 'SILENT' | 'MONITOR' | 'INVESTIGATE' | 'RECOMMEND' | 'ASK_APPROVAL' | 'ESCALATE'
export type AircraftStage = 'SIGHTED' | 'POTENTIAL' | 'CONFIRMED'
export type Role = 'customer' | 'operator' | 'broker' | 'admin'
export type EyeName = 'DISCOVERY' | 'OPERATOR' | 'JOURNEY'
export interface EyeSnapshot {
  agent: AgentState
  activeEyes: EyeName[]
  dataStatus: DataStatus
  isDemo: boolean
  updatedAt: string
}
