import type { EyeSnapshot, EyeName } from '../types'
const EYES: EyeName[] = ['DISCOVERY', 'OPERATOR', 'JOURNEY']
export function TopBar({ snap }: { snap: EyeSnapshot | null }) {
  return (
    <header id="bar">
      <b>THE KING'S EYE</b>
      {EYES.map((e) => <span key={e} className={`fc ${snap?.activeEyes.includes(e) ? 'on' : ''}`}>{e}</span>)}
      <span className="ed"><span className={snap?.agent === 'ANALYSING' ? 'on' : ''}>ANALYSING</span><span className={snap?.agent === 'ALL_CLEAR' ? 'on' : ''}>ALL CLEAR</span></span>
      {snap?.isDemo && <span className="pill">DEMO MODE · SIMULATION</span>}
    </header>
  )
}
