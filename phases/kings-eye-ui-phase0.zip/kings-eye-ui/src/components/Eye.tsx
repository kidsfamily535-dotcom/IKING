import type { AgentState } from '../types'
export function Eye({ state = 'IDLE' }: { state?: AgentState }) {
  const cls = state === 'ANALYSING' ? 'eye an' : state === 'ALL_CLEAR' ? 'eye ok' : 'eye'
  return <div className={cls} role="img" aria-label={`حالة العين: ${state}`}><i /></div>
}
