import { useState } from 'react'
import { api } from '../data/api'
import type { Role } from '../types'
const ROLES: { r: Role; l: string }[] = [
  { r: 'customer', l: 'عميل' }, { r: 'operator', l: 'مشغّل' }, { r: 'broker', l: 'وسيط' }, { r: 'admin', l: 'أدمن' },
]
// منتقي أدوار تجريبي — يُحذف بالكامل عند ربط تسجيل الدخول الحقيقي
export function RolePicker() {
  const [role, setRole] = useState<Role | null>(api.getRole())
  const pick = (r: Role | null) => { api.setRole(r); setRole(r) }
  return (
    <section className="sec" aria-label="دخول تجريبي">
      <div className="mono">DEMO ACCESS <span className="sim">SIMULATION</span></div>
      <p className="lead">اختر دورًا لمعاينة الشاشات. هذا ليس تسجيل دخول حقيقيًا ولا يمنح أي صلاحية.</p>
      <div className="ctl">
        {ROLES.map((x) => <button key={x.r} className={role === x.r ? 'on' : 'g'} onClick={() => pick(x.r)}>{x.l}</button>)}
        {role && <button className="g" onClick={() => pick(null)}>إلغاء</button>}
      </div>
    </section>
  )
}
