import type { DataStatus } from '../types'
const AR: Record<DataStatus, string> = {
  LIVE: 'مباشر', SIM: 'محاكاة', ESTIMATED: 'تقديري', UNKNOWN: 'غير معروف — يحتاج تحقق', CONFIRMED: 'مؤكد من المشغّل', INFERRED: 'استنتاج',
}
const TONE: Record<DataStatus, string> = { LIVE: 'ok', SIM: 'blue', ESTIMATED: 'blue', UNKNOWN: 'dim', CONFIRMED: 'gold', INFERRED: 'blue' }
export function StatusBadge({ status }: { status: DataStatus }) {
  return <span className={`badge ${TONE[status]}`} title={AR[status]}>{status}</span>
}
export const statusLabel = (s: DataStatus) => AR[s]
