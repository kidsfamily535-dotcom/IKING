import type { EyeApi } from './api'
import type { Role } from '../types'
let role: Role | null = null
export const api: EyeApi = {
  async getSnapshot() {
    return { agent: 'IDLE', activeEyes: ['DISCOVERY'], dataStatus: 'SIM', isDemo: true, updatedAt: new Date().toISOString() }
  },
  getRole: () => role,
  setRole: (r) => { role = r },
}
