// الشاشات تستورد من هذا الملف فقط. التوصيل بـ Supabase لاحقاً = استبدال التنفيذ.
import type { EyeSnapshot, Role } from '../types'
export interface EyeApi {
  getSnapshot(): Promise<EyeSnapshot>
  getRole(): Role | null
  setRole(role: Role | null): void
}
export { api } from './mockApi'
