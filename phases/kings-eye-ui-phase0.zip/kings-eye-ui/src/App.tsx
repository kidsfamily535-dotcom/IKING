import { useEffect, useState } from 'react'
import { api } from './data/api'
import type { EyeSnapshot, DataStatus } from './types'
import { Eye } from './components/Eye'
import { TopBar } from './components/TopBar'
import { StatusBadge, statusLabel } from './components/StatusBadge'
import { RolePicker } from './components/RolePicker'

const STATUSES: DataStatus[] = ['CONFIRMED', 'LIVE', 'ESTIMATED', 'INFERRED', 'SIM', 'UNKNOWN']
const RULES = [
  'لا توافر إلا بتأكيد المشغّل. الطائرة المرصودة ليست متاحة.',
  'لا سعر ولا زمن رحلة ولا تصريح من التخمين. المجهول يُكتب: غير معروف.',
  'كل رسالة وكل تفعيل بموافقة بشرية. العين تقترح والإنسان يقرر.',
  'لا نعرض للعميل رقم الذيل ولا بيانات المشغّل.',
]

export default function App() {
  const [snap, setSnap] = useState<EyeSnapshot | null>(null)
  useEffect(() => { api.getSnapshot().then(setSnap) }, [])
  return (
    <>
      <TopBar snap={snap} />
      <section className="hero">
        <div className="mono">ALWAYS WATCHING · 24 / 7</div>
        <h1>THE KING'S EYE</h1>
        <p className="sub">Supply seen. Demand <b>found.</b> Humans decide.</p>
        <Eye state={snap?.agent} />
        <p className="lead">عقل واحد. ثلاث عيون. وسيط رقمي لا ينام، ولا يعد بما لا يعرفه.</p>
      </section>
      <section className="sec">
        <div className="mono">TRUST SYSTEM</div>
        <h2>كل معلومة تحمل حالتها</h2>
        <p className="lead">لا شيء على الشاشة بلا مصدر أو حالة. هذه هي الحالات الست التي ستراها في كل مكان.</p>
        {STATUSES.map((s) => (
          <div className="row" key={s}><span>{statusLabel(s)}</span><StatusBadge status={s} /></div>
        ))}
      </section>
      <section className="sec">
        <div className="mono">NON-NEGOTIABLE</div>
        <h2>قواعد لا تتغير</h2>
        <ul className="rules">{RULES.map((r) => <li key={r}>{r}</li>)}</ul>
      </section>
      <RolePicker />
      <footer>المرحلة 0 · بيانات تجريبية فقط · لا اتصال بأي قاعدة بيانات</footer>
    </>
  )
}
