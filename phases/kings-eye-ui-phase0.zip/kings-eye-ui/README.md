# THE KING'S EYE — UI Phase 0
Vite + React + TypeScript. بيانات تجريبية فقط (src/data/mockApi.ts). الشاشات تستورد من src/data/api.ts فقط.
تشغيل: npm install ثم npm run dev. بناء: npm run build. النشر: Vercel (Framework: Vite).
