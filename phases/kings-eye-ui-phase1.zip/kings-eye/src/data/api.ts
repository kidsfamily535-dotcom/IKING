import type {Airport,Opportunity,Signal,AgentState} from './types';
export interface EyeApi{
 listAirports():Promise<Airport[]>;listSignals():Promise<Signal[]>;listOpportunities():Promise<Opportunity[]>;
 approveOpportunity(id:string):Promise<void>;rejectOpportunity(id:string,reason:string):Promise<void>;
 runPass(onState:(s:AgentState)=>void):Promise<string>;
}
export {mockApi as api} from './mockApi';
