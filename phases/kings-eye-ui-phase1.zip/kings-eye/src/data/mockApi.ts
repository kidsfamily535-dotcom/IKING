import type {EyeApi} from './api';import type {Airport,Opportunity,Signal} from './types';
const A=(iata:string,nameAr:string,nameEn:string,country:string,lat:number,lon:number):Airport=>({iata,nameAr,nameEn,country,lat,lon});
const airports:Airport[]=[A('RUH','الرياض','Riyadh','SA',24.957,46.699),A('JED','جدة','Jeddah','SA',21.679,39.157),A('MED','المدينة','Madinah','SA',24.553,39.705),A('TUU','تبوك','Tabuk','SA',28.365,36.619),A('DMM','الدمام','Dammam','SA',26.471,49.798),A('AHB','أبها','Abha','SA',18.24,42.656),A('GIZ','جازان','Jazan','SA',16.901,42.586),A('YNB','ينبع','Yanbu','SA',24.144,38.063),A('DXB','دبي','Dubai','AE',25.253,55.366),A('AUH','أبوظبي','Abu Dhabi','AE',24.433,54.651),A('DOH','الدوحة','Doha','QA',25.273,51.608),A('CAI','القاهرة','Cairo','EG',30.122,31.406),A('AMM','عمّان','Amman','JO',31.722,35.993)];
const signals:Signal[]=[
{id:'s1',kind:'OPERATOR',title:'رحلة فاضية RUH → JED أكّدها المشغّل',area:'الرياض',stage:'CONFIRMED',dataStatus:'CONFIRMED',confidence:'high',source:'OFFICIAL_OPERATOR',minutesAgo:12,priority:'APPROVAL_REQUIRED'},
{id:'s2',kind:'OPERATOR',title:'سعة مقترحة DMM → DXB في انتظار تحقق الفريق',area:'الدمام',stage:'POTENTIAL',dataStatus:'UNKNOWN',confidence:'low',source:'INTERNAL_DATABASE',minutesAgo:41,priority:'INVESTIGATE'},
{id:'s3',kind:'AIRCRAFT_MOVEMENT',title:'طائرة كبيرة المقصورة تتحرك غرب جدة',area:'منطقة جدة',stage:'SIGHTED',dataStatus:'SIM',confidence:'medium',source:'ADS-B (محاكاة)',minutesAgo:6,priority:'WATCH'},
{id:'s4',kind:'AIRCRAFT_MOVEMENT',title:'حركة محتملة نحو الرياض من الخليج',area:'الخليج',stage:'POTENTIAL',dataStatus:'INFERRED',confidence:'medium',source:'استنتاج النظام',minutesAgo:19,priority:'WATCH'},
{id:'s5',kind:'DEMAND',title:'فعالية أعمال في الرياض الأسبوع القادم',area:'الرياض',dataStatus:'SIM',confidence:'low',grade:'D',source:'مصدر عام',minutesAgo:95,priority:'WATCH'},
{id:'s6',kind:'WEATHER',title:'الطقس مقبول على مسار RUH → JED',area:'الرياض / جدة',dataStatus:'SIM',confidence:'medium',source:'METAR (محاكاة)',minutesAgo:8,priority:'SILENT'}];
let opps:Opportunity[]=[
{id:'o1',origin:'RUH',destination:'JED',aircraftCategory:'متوسطة المقصورة',seats:7,trigger:'LAST_MINUTE',status:'ACTIVATION_PENDING',availability:'CONFIRMED',source:'OFFICIAL_OPERATOR',verifiedMinAgo:12,expiresInMin:168,scoreParts:{freshness:28,sourceStrength:20,urgency:24,confidence:16},reasons:['المشغّل أكّد الرحلة قبل 12 دقيقة','موعد المغادرة خلال ساعتين تقريبًا (من بيانات حقيقية)','المسار مطلوب عادةً من عملاء الرياض'],matched:{segment:'LATENT',relevance:62,gate:'ALLOWED'},isDemo:true,note:'بيانات تجريبية'},
{id:'o2',origin:'DMM',destination:'DXB',aircraftCategory:'خفيفة',seats:5,trigger:'AVAILABILITY',status:'DETECTED',availability:'PENDING_VERIFICATION',source:'INTERNAL_DATABASE',verifiedMinAgo:null,expiresInMin:600,scoreParts:{freshness:14,sourceStrength:8,urgency:6,confidence:6},reasons:['سعة مسجّلة لكن لم يؤكدها المشغّل بعد'],matched:{segment:'DORMANT',relevance:31,gate:'BLOCKED',gateReason:'التوافر غير مؤكد، ولا يُعرض على أي عميل قبل التحقق'},isDemo:true,note:'بيانات تجريبية'}];
const wait=(ms:number)=>new Promise(r=>setTimeout(r,ms));
export const mockApi:EyeApi={
 async listAirports(){await wait(80);return airports},
 async listSignals(){await wait(120);return signals},
 async listOpportunities(){await wait(120);return opps.map(o=>({...o}))},
 async approveOpportunity(id){await wait(300);opps=opps.map(o=>o.id===id&&o.status==='ACTIVATION_PENDING'?{...o,status:'ACTIVATED'}:o)},
 async rejectOpportunity(id,reason){if(!reason.trim())throw new Error('reason required');await wait(300);opps=opps.map(o=>o.id===id?{...o,status:'REJECTED',note:reason}:o)},
 async runPass(on){for(const s of ['DISCOVERING','THINKING','MATCHING','MONITORING'] as const){on(s);await wait(700)}on('WATCHING');return 'العين راجعت 6 إشارات: فرصة واحدة جاهزة لموافقتك، وأخرى تنتظر تحقق الفريق.'}};
