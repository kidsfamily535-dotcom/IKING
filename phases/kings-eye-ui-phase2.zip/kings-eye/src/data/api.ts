import type {Airport,Opportunity,Signal,AgentState,EmptyLegInput,EmptyLegResult,MarketLeg,MemoryItem,ParsedRequest,DecisionPolicyRow} from './types';
export interface EyeApi{
 listAirports():Promise<Airport[]>;listSignals():Promise<Signal[]>;listOpportunities():Promise<Opportunity[]>;
 approveOpportunity(id:string):Promise<void>;rejectOpportunity(id:string,reason:string):Promise<void>;
 analyzeEmptyLeg(i:EmptyLegInput,onStep:(s:string)=>void):Promise<EmptyLegResult>;listMarket():Promise<MarketLeg[]>;
 runPass(onState:(s:AgentState)=>void):Promise<string>;
}
export {mockApi as api} from './mockApi';
